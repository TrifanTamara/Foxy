﻿namespace UnitTests
{
    public class Class1
    {
    }
}
