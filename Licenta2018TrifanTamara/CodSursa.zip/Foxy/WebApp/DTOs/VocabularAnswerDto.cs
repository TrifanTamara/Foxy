﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApp.DTOs
{
    public class VocabularAnswerDto
    {
        public string Meaning { get; set; }
        public string Reading { get; set; }
    }
}
