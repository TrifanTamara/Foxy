﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApp.DTOs
{
    static public class SharedInfo
    {
        public static String RegisterError = String.Empty;
        public static String LoginError = String.Empty;
        public static String ShowSuccessMessage = String.Empty;
    }
}
