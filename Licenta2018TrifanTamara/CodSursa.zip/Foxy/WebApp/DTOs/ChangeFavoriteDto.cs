﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApp.DTOs
{
    public class ChangeFavoriteDto
    {
        public Guid VocabularId { get; set; }
    }
}
