﻿namespace IntegrationTests
{
    public class Class1
    {
    }
}
